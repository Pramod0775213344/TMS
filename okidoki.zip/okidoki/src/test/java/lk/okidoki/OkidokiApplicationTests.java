package lk.okidoki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OkidokiApplicationTests {

	@Test
	void contextLoads() {
	}

}
