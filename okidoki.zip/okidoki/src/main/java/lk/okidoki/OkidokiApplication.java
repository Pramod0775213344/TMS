package lk.okidoki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OkidokiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OkidokiApplication.class, args);
	}

}
